<?php
/**
 * The template for displaying the header layout
 *
 * @package Kandinsky
 */

get_template_part( 'template-parts/headers/header', knd_get_header_type() );
